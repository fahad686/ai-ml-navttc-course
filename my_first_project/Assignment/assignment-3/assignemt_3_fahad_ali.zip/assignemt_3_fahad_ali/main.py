from calculation import *

calculator()