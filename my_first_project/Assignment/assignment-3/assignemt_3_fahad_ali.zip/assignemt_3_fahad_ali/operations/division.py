def dividing(a,b):
    return  a/b