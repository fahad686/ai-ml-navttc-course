def multiple(a,b):
    return a*b