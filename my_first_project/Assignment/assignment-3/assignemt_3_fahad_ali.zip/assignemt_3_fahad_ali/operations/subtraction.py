def subtract_func(x,y):
    return x-y